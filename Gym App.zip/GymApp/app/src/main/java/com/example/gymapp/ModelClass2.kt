package com.example.gymapp

data class ModelClass2(var exTypeImage : String , var exTypeName: String )
