package com.example.gymapp

data class DataModel(var exerciseImg:String , var exerciseName:String )
