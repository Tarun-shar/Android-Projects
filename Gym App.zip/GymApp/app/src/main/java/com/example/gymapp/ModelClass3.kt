package com.example.gymapp

data class ModelClass3(var exName:String , var day:String , var time:String)
