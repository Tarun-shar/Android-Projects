package com.example.dicerolar

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import com.example.dicerolar.databinding.ActivityMainBinding
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    val binding by lazy {
        ActivityMainBinding.inflate(layoutInflater)
    }

    var score1 = 0
    var score2 = 0
    var isFirstPlayer = true
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(binding.root)

        // byDefault score of both player
        binding.player1Score.text = "Player 1 Score : \n $score1"
        binding.player2Score.text = "Player 2 Score : \n $score2"

        binding.diceRoll.setOnClickListener {

            // random number to random image
            var number = Random.nextInt(1,7) // till the 6

            // Selection of image
            var image = when(number){
                1->R.drawable.dice_1
                2->R.drawable.dice_2
                3->R.drawable.dice_3
                4->R.drawable.dice_4
                5->R.drawable.dice_5
                else->R.drawable.dice_6
            }
            // increase player score
            if(isFirstPlayer){
                score1+=number
                // update score
                binding.player1Score.text = "Player 1 Score : \n $score1"
            }
            else{
                score2+=number
                //update score
                binding.player2Score.text = "Player 2 Score : \n $score2"
            }

            // check condition
            if(score1>=20 || score2>=20){
                binding.resultView.visibility = View.VISIBLE
                binding.winner.setText("Winner is ${if(score1>score2) "Player 1" else "Player 2"} and Score is ${if(score1>score2) score1 else score2 }")
            }

            // set image
            binding.diceImage.setImageResource(image)

            // update button label
            binding.diceRoll.setText(if(isFirstPlayer){
                "Player 2"
            }
            else{
                "Player 1"
        })

            // changing the player
//            if(isFirstPlayer){
//                isFirstPlayer=false
//            }
//            else{
//                isFirstPlayer=true
//            }

            // we can also write professionally like this for changing the player code
            isFirstPlayer = !isFirstPlayer

        }
    }
}