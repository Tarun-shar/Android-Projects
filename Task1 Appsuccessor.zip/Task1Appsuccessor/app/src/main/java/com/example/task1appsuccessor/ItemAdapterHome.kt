package com.example.task1appsuccessor

import android.R
import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.task1appsuccessor.databinding.RecycleItemFileBinding

class ItemAdapterHome (var dataList: ArrayList<dataClassHome>, var context: Context): RecyclerView.Adapter<ItemAdapterHome.ViewHolder>() {

    class ViewHolder(val binding: RecycleItemFileBinding): RecyclerView.ViewHolder(binding.root)

    //    searchView work 17 to 20
    fun setFilteredList(dataList: ArrayList<dataClassHome>){
        this.dataList = dataList
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView = RecycleItemFileBinding.inflate(LayoutInflater.from(context),parent,false)
        return ViewHolder(itemView)
    }

    override fun getItemCount(): Int {
        return dataList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val module = dataList[position]
        holder.binding.phoneName.text = dataList[position].name
        holder.binding.description.text = dataList[position].des
        Glide.with(context).load(module.img).into(holder.binding.ImageView)

        holder.binding.cardView.setOnClickListener {
            val toast = Toast.makeText(context, dataList[position].name, Toast.LENGTH_SHORT)
            val toastView = toast.view
            toastView!!.setBackgroundResource(R.color.darker_gray)
            toast.show()
        }
    }


}