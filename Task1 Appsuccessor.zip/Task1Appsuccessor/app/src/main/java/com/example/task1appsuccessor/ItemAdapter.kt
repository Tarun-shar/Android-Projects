package com.example.task1appsuccessor

import android.R
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.task1appsuccessor.databinding.RecycleItemFileBinding

class ItemAdapter(var dataList: ArrayList<dataClass>, var context: Context): RecyclerView.Adapter<ItemAdapter.ViewHolder>() {

    class ViewHolder(val binding: RecycleItemFileBinding): RecyclerView.ViewHolder(binding.root)

    //    searchView work 18 to 21
    fun setFilteredList(dataList: ArrayList<dataClass>){
        this.dataList = dataList
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView = RecycleItemFileBinding.inflate(LayoutInflater.from(context),parent,false)
        return ViewHolder(itemView)
    }

    override fun getItemCount(): Int {
        return dataList.size
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.binding.phoneName.text = dataList[position].phone
        holder.binding.description.text = dataList[position].discription
        Glide.with(context).load(dataList[position].image).into(holder.binding.ImageView)

        holder.binding.cardView.setOnClickListener {
            val toast = Toast.makeText(context, dataList[position].phone, Toast.LENGTH_SHORT)
            val toastView = toast.view
            toastView!!.setBackgroundResource(R.color.darker_gray)
            toast.show()
            
            val intent = Intent(context,DetailsActivity::class.java)
            intent.putExtra("Image",dataList[position].image)
            intent.putExtra("title",dataList[position].phone)
            intent.putExtra("description",dataList[position].discription)
            context.startActivity(intent)


        }
    }
}