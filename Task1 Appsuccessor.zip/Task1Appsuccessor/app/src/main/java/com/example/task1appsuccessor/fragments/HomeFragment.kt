package com.example.task1appsuccessor.fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SearchView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.task1appsuccessor.ItemAdapterHome
import com.example.task1appsuccessor.Onboarding1
import com.example.task1appsuccessor.R
import com.example.task1appsuccessor.dataClassHome
import com.example.task1appsuccessor.databinding.FragmentHomeBinding
import com.google.firebase.auth.FirebaseAuth
import java.util.Locale

class HomeFragment : Fragment() {

    lateinit var adapterObj:ItemAdapterHome
    lateinit var dataList: ArrayList<dataClassHome>

    lateinit var firebaseAuth : FirebaseAuth

    lateinit var binding:FragmentHomeBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        binding = FragmentHomeBinding.inflate(layoutInflater,container,false)

        dataList = ArrayList()

        firebaseAuth = FirebaseAuth.getInstance()

        binding.logOut.setOnClickListener {
            val toast = Toast.makeText(context, "User LogOut!", Toast.LENGTH_SHORT)
            val toastView = toast.view
            toastView!!.setBackgroundResource(android.R.color.darker_gray)
            toast.show()
            firebaseAuth.signOut()
            startActivity(Intent(context,Onboarding1::class.java))
            requireActivity().finish()
        }
//
//        //        Share preference work
//        val sharePrefObj: SharedPreferences =  requireActivity().getSharedPreferences("sharePrefId",
//            AppCompatActivity.MODE_PRIVATE
//        )
//
//        val image = sharePrefObj.getString("storeImage",null).toString()
//        val title = sharePrefObj.getString("storeTitle",null).toString()
//        val description = sharePrefObj.getString("storeDes",null).toString()

//        dataList.add(dataClassHome(image,title,description))
        dataList.add(dataClassHome(R.drawable.img,"i Phone","An Apple mobile which is nothing like apple"))
        dataList.add(dataClassHome(R.drawable.img,"Samsung","An Apple mobile which is nothing like apple"))
        dataList.add(dataClassHome(R.drawable.img,"RealMe","An Apple mobile which is nothing like apple"))
        dataList.add(dataClassHome(R.drawable.img,"Redmi","An Apple mobile which is nothing like apple"))
        dataList.add(dataClassHome(R.drawable.img,"Poco","An Apple mobile which is nothing like apple"))
        dataList.add(dataClassHome(R.drawable.img,"Motorola","An Apple mobile which is nothing like apple"))

        adapterObj = ItemAdapterHome(dataList , requireContext())

        binding.recyclerViewHome.layoutManager = LinearLayoutManager(context,LinearLayoutManager.VERTICAL,false)

        binding.recyclerViewHome.adapter = adapterObj

        //        SearchView Work
        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener{
            override fun onQueryTextSubmit(p0: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(p0: String?): Boolean {
                filterList(p0)
                return true
            }
        })

//        if(dataList != null){
//            binding.fetchDatabase.visibility = VISIBLE
//            binding.noDatabase.visibility = GONE
//        }
//        else{
//            binding.fetchDatabase.visibility = GONE
//            binding.noDatabase.visibility = VISIBLE
//        }

        return binding.root
    }

//    searchView Function
    private fun filterList(query: String?) {
        if(query != null){
            val filterList = ArrayList<dataClassHome>()
            for(i in dataList){
                if(i.name.toLowerCase(Locale.ROOT).contains(query)){
                    filterList.add(i)
                }
            }
            if(filterList.isEmpty()){
                val toast = Toast.makeText(context, "No Data Found", Toast.LENGTH_SHORT)
                val toastView = toast.view
                toastView!!.setBackgroundResource(android.R.color.darker_gray)
                toast.show()
            }
            else{
                adapterObj.setFilteredList(filterList)
            }
        }
    }
}

