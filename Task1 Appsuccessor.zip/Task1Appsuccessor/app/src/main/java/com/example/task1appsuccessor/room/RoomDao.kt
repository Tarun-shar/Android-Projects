package com.example.task1appsuccessor.room

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.example.task1appsuccessor.dataClass

@Dao
interface RoomDao {

    @Insert
    suspend fun insertProduct(product : List<dataClass>)

    @Query("SELECT * FROM ProductsData")
    suspend fun getProduct() : List<dataClass>
}