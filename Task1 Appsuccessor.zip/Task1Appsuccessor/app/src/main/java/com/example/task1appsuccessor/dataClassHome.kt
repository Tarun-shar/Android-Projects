package com.example.task1appsuccessor

data class dataClassHome(var img: Int, var name:String, var des:String)
