package com.example.task1appsuccessor.fragments

import android.R
import android.app.ProgressDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.SearchView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.example.task1appsuccessor.ItemAdapter
import com.example.task1appsuccessor.dataClass
import com.example.task1appsuccessor.databinding.FragmentAPIBinding
import org.json.JSONObject
import java.util.Locale

class APIFragment : Fragment() {

    var url = "https://dummyjson.com/products"
    lateinit var adapterObj: ItemAdapter
    lateinit var dataList: ArrayList<dataClass>

    lateinit var binding: FragmentAPIBinding
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?,
    ): View? {
        binding = FragmentAPIBinding.inflate(layoutInflater,container,false)

        dataList = ArrayList()

        val progressDialog = ProgressDialog(requireContext())
        progressDialog.setMessage("Please wait while data is loading")
        progressDialog.show()

        val queue = Volley.newRequestQueue(context)

// Request a string response from the provided URL.
        val stringRequest = StringRequest(
            Request.Method.GET, url,
            { response ->

                val responseObj = JSONObject(response)
                val arrayObj = responseObj.getJSONArray("products")
                for (i in 0 until arrayObj.length()){
                    val resObj1 = arrayObj.getJSONObject(i)

                    val apiId = resObj1.get("id").toString()
                    val apiImage = resObj1.get("thumbnail").toString()
                    val apiTitle = resObj1.get("title").toString()
                    val apiDis = resObj1.get("description").toString()

////                    sharedPreference work
//                    val editor: SharedPreferences.Editor =  requireActivity().getSharedPreferences("sharePrefId", MODE_PRIVATE
//                    ).edit()
//                    editor.putString("storeImage",apiImage)
//                    editor.putString("storeTitle",apiTitle)
//                    editor.putString("storeDes",apiDis)
//                    editor.apply()

                    // data store in Share Preference
                    dataList.add(dataClass(apiId,apiImage,apiTitle,apiDis))

                    adapterObj = ItemAdapter(dataList , requireContext())

                    binding.recyclerView.layoutManager = LinearLayoutManager(context,LinearLayoutManager.VERTICAL,false)

                    binding.recyclerView.adapter = adapterObj

                    progressDialog.dismiss()

                }
            },
            { error ->
                progressDialog.dismiss()
                    val toast = Toast.makeText(context, "Please Check Your Internet Connection!", Toast.LENGTH_SHORT)
                    val toastView = toast.view
                    toastView!!.setBackgroundResource(R.color.darker_gray)
                    toast.show()
            })

// Add the request to the RequestQueue.
        queue.add(stringRequest)

//        SearchView Work
        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener{
            override fun onQueryTextSubmit(p0: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(p0: String?): Boolean {
                filterList(p0)
                return true
            }
        })
        return binding.root
    }

    private fun filterList(query: String?) {
        if(query != null){
            val filterList = ArrayList<dataClass>()
            for(i in dataList){
                if(i.phone.toLowerCase(Locale.ROOT).contains(query)){
                    filterList.add(i)
                }
            }
            if(filterList.isEmpty()){
                val toast = Toast.makeText(context, "No Data Found", Toast.LENGTH_SHORT)
                val toastView = toast.view
                toastView!!.setBackgroundResource(R.color.darker_gray)
                toast.show()
            }
            else{
                adapterObj.setFilteredList(filterList)
            }
        }
    }
}

