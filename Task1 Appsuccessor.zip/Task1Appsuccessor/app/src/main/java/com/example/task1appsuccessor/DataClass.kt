package com.example.task1appsuccessor

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "ProductsData")
data class dataClass(

    @PrimaryKey
    var id:String,

    var image:String,
    var phone:String,
    var discription:String)
