package com.example.calciproject

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.WindowManager
import com.example.calciproject.databinding.ActivityMainBinding
import javax.script.ScriptEngineManager

class MainActivity : AppCompatActivity() {

    private var input : String = ""
    lateinit var binding : ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        this.window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN , WindowManager.LayoutParams.FLAG_FULLSCREEN)

        binding.btnAC.setOnClickListener {
            input = ""
            binding.inputText.text = input
            binding.resultText.text = input
        }

        binding.btn0.setOnClickListener {
            updateString(0)
        }

        binding.btn1.setOnClickListener {
            updateString(1)
        }

        binding.btn2.setOnClickListener {
            updateString(2)
        }

        binding.btn3.setOnClickListener {
            updateString(3)
        }

        binding.btn4.setOnClickListener {
            updateString(4)
        }

        binding.btn5.setOnClickListener {
            updateString(5)
        }

        binding.btn6.setOnClickListener {
            updateString(6)
        }

        binding.btn7.setOnClickListener {
            updateString(7)
        }

        binding.btn8.setOnClickListener {
            updateString(8)
        }

        binding.btn9.setOnClickListener {
            updateString(9)
        }

        binding.btnBracketStart.setOnClickListener {
            updateString("(")
        }

        binding.btnBracketClose.setOnClickListener {
            updateString(")")
        }

        binding.btnDot.setOnClickListener {
            input += "."
            binding.inputText.text = input
        }

        binding.btnPlus.setOnClickListener {
            updateString("+")
        }

        binding.btnMinus.setOnClickListener {
            updateString("-")
        }

        binding.btnMultiply.setOnClickListener {
            updateString("*")
        }

        binding.btnDivide.setOnClickListener {
            updateString("/")
        }

        binding.btnC.setOnClickListener {
            try{
            input = input.substring(0,input.length-1)
            binding.inputText.text = input
            }
            catch (_: Exception){
            }
        }

        binding.btnEqual.setOnClickListener {
            try{
            val engine = ScriptEngineManager().getEngineByName("rhino")
//                eval = evaluate
            binding.resultText.text = engine.eval(input).toString()
        }
            catch (_: Exception){
            }
        }
    }

    private fun updateString(i: Int) {
        input += i
        binding.inputText.text = input
    }

    private fun updateString(s: String) {
        input += s
        binding.inputText.text = input
    }
}